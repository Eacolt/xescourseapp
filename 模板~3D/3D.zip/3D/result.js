$(function(){
	var Spell = function() {
		
	}
    Spell();
})