var configData = {
    "one": {
  		"title": "",
  		"des": "",
        "bg": "",
        'soundImg':'./images/sound.png',
        "topImg":'./assets/images/top_text.png',/*顶部图片*/
    },
    "source": [{
            "subTitle":"",
            "questionList": [
                {
                    text:'',
                    img: './assets/images/001.png',
                    audio1: './assets/audios/1.wav',
                },
                {
                    text:'',
                    img: './assets/images/002.png',
                    audio1: './assets/audios/2.wav',
                },
                {
                    text:'',
                    img: './assets/images/003.png',
                    audio1: './assets/audios/3.wav',
                },{
                    text:'',
                    img: './assets/images/004.png',
                    audio1: './assets/audios/4.wav',
                },{
                    text:'',
                    img: './assets/images/005.png',
                    audio1: './assets/audios/5.wav',
                },{
                    text:'',
                    img: './assets/images/006.png',
                    audio1: './assets/audios/1.wav',
                }/*,
                {
                    text:'',
                    img: './assets/images/002.png',
                    audio1: './assets/audios/2.wav',
                },
                {
                    text:'',
                    img: './assets/images/003.png',
                    audio1: './assets/audios/3.wav',
                },{
                    text:'',
                    img: './assets/images/004.png',
                    audio1: './assets/audios/4.wav',
                },{
                    text:'',
                    img: './assets/images/001.png',
                    audio1: './assets/audios/5.wav',
                }*/
            ]
    }]
};
(function (pageNo) { configData.page = pageNo })(7)